﻿using System.Runtime.CompilerServices;

namespace egz2306
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n = 100;
            bool[] sita = new bool[n + 1];
            for(int i = 2 ; i <= n; i++)
            {
                sita[i] = true;
            }

            for (int p = 2 ; p * p <= n ; p++)
            {
                if (sita[p] == true)
                {
                    for (int i = p * p ; i <= n; i +=p)
                    {
                        sita[i] = false;
                    }
                }
            }
            Console.WriteLine("Liczby pierwsze");
            for (int i = 2 ; i <= n; i++)
            {
                if (sita[i] == true)
                {
                    Console.WriteLine(i + "");
                }
            }
        }
    }
}